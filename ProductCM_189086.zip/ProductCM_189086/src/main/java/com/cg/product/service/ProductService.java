package com.cg.product.service;

import java.util.ArrayList;

import com.cg.product.dto.Product;

public interface ProductService {
	public Product addUser(Product pr);

	public void updateUser(String id, String name, double price);

	public void deleteUser(String id);

	public Product getProductById(String id);

	public ArrayList<Product> showAllProducts();
}
