package com.cg.product.ctrl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.product.dto.Product;
import com.cg.product.exception.ProductNotFoundException;
import com.cg.product.service.ProductService;

@RestController
public class ProductController {

	// Creating object of Service Class using auto wired
	@Autowired
	ProductService ser;

	// Adding the Product using Post Mapping
	@PostMapping(value = "/addUser", consumes = MediaType.APPLICATION_JSON_VALUE, headers = "Accept=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
	public Product createUser(@RequestBody Product pr) throws ProductNotFoundException {
		ser.addUser(pr);
		System.out.println(pr);
		Product pro = ser.getProductById(pr.getId());
		if (pro == null) {
			throw new ProductNotFoundException("Wrong Format...Please try Again");
		} else {
			System.out.println("Data Added");
			return pro;
		}
	}

	// Showing all the Products using Get Mapping
	@RequestMapping(value = "/showAllUsers", method = RequestMethod.GET, headers = "Accept=application/json")
	public ArrayList<Product> showAllProducts() throws ProductNotFoundException {
		ArrayList<Product> pr = ser.showAllProducts();
		System.out.println(pr);
		if (pr == null) {
			throw new ProductNotFoundException("Empty Database...Please add Something");
		} else {
			System.out.println("Data Found" + pr);
			return pr;
		}
	}

	// Deleting the Product using Delete Mapping
	@DeleteMapping(value = "/deleteUser/{id}", headers = "Accept=application/json")
	public void deleteProduct(@PathVariable("id") String id) {
		ser.deleteUser(id);
		System.out.println("Data Deleted");
	}

	// Updating the Product using Put Mapping
	@PutMapping(value = "/users/update/", consumes = MediaType.APPLICATION_JSON_VALUE, headers = "Accept=application/json")
	public void updateProduct(@RequestBody Product product) {
		ser.updateUser(product.getId(), product.getName(), product.getPrice());
		System.out.println("Data Updated");
	}

	// Searching the Product using Get Mapping
	@GetMapping(value = "searchUser/{id}")
	public Product showProduct(@PathVariable("id") String id) throws ProductNotFoundException {
		Product pr = ser.getProductById(id);
		if (pr == null) {
			throw new ProductNotFoundException("Wrong Product Id is Submitted...Please try Again");
		} else {
			System.out.println("Data Found" + pr);
			return pr;
		}
	}
}
