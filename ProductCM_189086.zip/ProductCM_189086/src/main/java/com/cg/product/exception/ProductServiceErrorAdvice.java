package com.cg.product.exception;

import java.sql.SQLException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ProductServiceErrorAdvice {

	@ExceptionHandler({ProductNotFoundException.class,SQLException.class})
	protected ResponseEntity<String> handle(ProductNotFoundException prexp)
	{
		return error(HttpStatus.INTERNAL_SERVER_ERROR,prexp);
	}
	
	protected ResponseEntity<String> error(HttpStatus status,ProductNotFoundException prexp)
	{
		return ResponseEntity.status(status).body(prexp.getMessage());
	}
}
