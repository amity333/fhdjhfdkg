package com.cg.product.ProductCM_189086;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductCm189086Application {

	public static void main(String[] args) {
		SpringApplication.run(ProductCm189086Application.class, args);
	}

}
