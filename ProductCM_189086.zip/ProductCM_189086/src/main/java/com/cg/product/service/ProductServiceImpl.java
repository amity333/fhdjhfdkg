package com.cg.product.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.dao.ProductRepository;
import com.cg.product.dto.Product;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {

	// Creating object of DAO using Auto wired
	@Autowired
	ProductRepository repo;

	@Override
	public Product addUser(Product pr) {
	//Using built-in function to add the Product
		return repo.save(pr);
	}

	@Override
	public void updateUser(String id, String name, double price) {
		repo.updateProductById(id, name, price);
	}

	@Override
	public void deleteUser(String id) {
		repo.deleteProductById(id);
	}

	@Override
	public Product getProductById(String id) {
		return repo.getProductById(id);
	}

	@Override
	public ArrayList<Product> showAllProducts() {
		return repo.showAllProducts();
	}

}
